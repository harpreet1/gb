<?php
App::uses('BlocksController', 'Controller');

/**
 * BlocksController Test Case
 *
 */
class BlocksControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.block'
	);

}
