<?php
App::uses('ProductsController', 'Controller');

/**
 * ProductsController Test Case
 *
 */
class ProductsControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.product',
		'app.user',
		'app.category',
		'app.subcategory',
		'app.subsubcategory',
		'app.ustradition',
		'app.nutrition',
		'app.tag',
		'app.products_tag'
	);

/**
 * testSlug method
 *
 * @return void
 */
	public function testSlug() {
	}

/**
 * testIndex method
 *
 * @return void
 */
	public function testIndex() {
	}

/**
 * testSubcategory method
 *
 * @return void
 */
	public function testSubcategory() {
	}

/**
 * testSubsubcategory method
 *
 * @return void
 */
	public function testSubsubcategory() {
	}

/**
 * testView method
 *
 * @return void
 */
	public function testView() {
	}

/**
 * testSearch method
 *
 * @return void
 */
	public function testSearch() {
	}

/**
 * testSearchjson method
 *
 * @return void
 */
	public function testSearchjson() {
	}

/**
 * testSitemap method
 *
 * @return void
 */
	public function testSitemap() {
	}

/**
 * testAdminReset method
 *
 * @return void
 */
	public function testAdminReset() {
	}

/**
 * testAdminIndex method
 *
 * @return void
 */
	public function testAdminIndex() {
	}

/**
 * testAdminView method
 *
 * @return void
 */
	public function testAdminView() {
	}

/**
 * testAdminAdd method
 *
 * @return void
 */
	public function testAdminAdd() {
	}

/**
 * testAdminEdit method
 *
 * @return void
 */
	public function testAdminEdit() {
	}

/**
 * testAdminDelete method
 *
 * @return void
 */
	public function testAdminDelete() {
	}

}
